using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Azure;
using KikiStore.Services;
using KikiStore.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using KikiStore.Areas.Identity.Data;

var builder = WebApplication.CreateBuilder(args);

// Access the configuration object
var configuration = builder.Configuration;

// Add services to the container.

var connectionString = builder.Configuration.GetConnectionString("azureDBConnect") ?? throw new InvalidOperationException("Connection string 'DefaultConnection not found.");
    builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));

    builder.Services.AddDefaultIdentity<KikiStoreUser>(options => options.SignIn.RequireConfirmedAccount = true).AddEntityFrameworkStores<KikiStoreDbContext>();

builder.Services.AddRazorPages();

// Register HttpClient in the DI container
builder.Services.AddHttpClient();

// Register BlobStorageService with the connection string
builder.Services.AddSingleton<BlobStorageService>(sp =>
{
    var connectionString = configuration.GetConnectionString("AzureWebJobsStorage");
    return new BlobStorageService(connectionString);
});

// Register TableStorageService with HttpClient injection
builder.Services.AddSingleton<TableStorageService>();

// Register QueueService with the connection string and queue name
builder.Services.AddSingleton<QueueService>(sp =>
{
    var connectionString = configuration.GetConnectionString("AzureWebJobsStorage");
    return new QueueService(connectionString, "transaction");
});

// Register AzureFileShareService with the connection string
builder.Services.AddSingleton<AzureFileShareService>(sp =>
{
    var connectionString = configuration.GetConnectionString("AzureWebJobsStorage");
    return new AzureFileShareService(connectionString);
});

// Build the app
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

// Set up the default controller route
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
app.MapRazorPages();

app.Run();




