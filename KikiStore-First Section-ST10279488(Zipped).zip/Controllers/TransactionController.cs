﻿using KikiStore.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace KikiStore.Controllers
{
    public class TransactionController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly string FunctionBaseUrl = "https://retailapp-st10279488.azurewebsites.net/";


        public TransactionController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IActionResult> Index()
        {
            var response = await _httpClient.GetAsync(FunctionBaseUrl + "GetAllTransactions");

            if (response.IsSuccessStatusCode)
            {
                var jsonResponse = await response.Content.ReadAsStringAsync();
                var transactions = JsonConvert.DeserializeObject<List<Transaction>>(jsonResponse);
                return View(transactions);
            }

            ModelState.AddModelError("", "Error retrieving transactions.");
            return View(new List<Transaction>());
        }


        public async Task<IActionResult> Register()
        {
            // Fetch customers and items from Azure Functions
            var customersResponse = await _httpClient.GetAsync(FunctionBaseUrl + "GetAllCustomers");
            var itemsResponse = await _httpClient.GetAsync(FunctionBaseUrl + "GetAllStores");

            if (!customersResponse.IsSuccessStatusCode || !itemsResponse.IsSuccessStatusCode)
            {
                ModelState.AddModelError("", "Error fetching data.");
                return View();
            }

            var customers = JsonConvert.DeserializeObject<List<Customer>>(await customersResponse.Content.ReadAsStringAsync());
            var items = JsonConvert.DeserializeObject<List<Store>>(await itemsResponse.Content.ReadAsStringAsync());

            if (customers == null || customers.Count == 0)
            {
                ModelState.AddModelError("", "No customers found. Please add customers first.");
                return View();
            }

            if (items == null || items.Count == 0)
            {
                ModelState.AddModelError("", "No items found. Please add items first.");
                return View();
            }

            ViewData["Customers"] = customers;
            ViewData["Items"] = items;

            return View();
        }

        // Action to handle the form submission and register the transaction
        [HttpPost]
        public async Task<IActionResult> Register(Transaction transaction)
        {
            if (ModelState.IsValid)
            {
                transaction.TransactionDate = DateTime.SpecifyKind(transaction.TransactionDate, DateTimeKind.Utc);
                var json = JsonConvert.SerializeObject(transaction);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                // Call the Azure Function to add the transaction
                var response = await _httpClient.PostAsync(FunctionBaseUrl + "StoreTransactionData", content);

                if (response.IsSuccessStatusCode)
                {
                    string message = $"New transaction by Customer {transaction.CustomerId} for Item {transaction.ItemId} at {transaction.Location} on {transaction.TransactionDate}";
                    await _httpClient.PostAsync(FunctionBaseUrl + "SendQueueMessage", new StringContent(message));

                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError("", "Error adding transaction.");
                }
            }

            var customersResponse = await _httpClient.GetAsync(FunctionBaseUrl + "GetAllCustomers");
            var itemsResponse = await _httpClient.GetAsync(FunctionBaseUrl + "GetAllStores");

            var customers = JsonConvert.DeserializeObject<List<Customer>>(await customersResponse.Content.ReadAsStringAsync());
            var items = JsonConvert.DeserializeObject<List<Store>>(await itemsResponse.Content.ReadAsStringAsync());

            ViewData["Customers"] = customers;
            ViewData["Items"] = items;

            return View(transaction);
        }

        // Action to delete a transaction
        [HttpPost]
        public async Task<IActionResult> DeleteTransaction(string partitionKey, string rowKey)
        {
            var response = await _httpClient.DeleteAsync($"{FunctionBaseUrl}DeleteTransaction?partitionKey={partitionKey}&rowKey={rowKey}");

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            ModelState.AddModelError("", "Error deleting transaction.");
            return RedirectToAction("Index");
        }
    }
}
