﻿using KikiStore.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic; // Ensure this is included for List<T>
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace KikiStore.Controllers
{
    public class CustomerController : Controller
    {
        private readonly HttpClient _httpClient;
        private const string FunctionBaseUrl = "https://retailapp-st10279488.azurewebsites.net/";

        public CustomerController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        [HttpGet]
        public IActionResult AddCustomer()
        {
            return View("Create");
        }

        [HttpPost]
        public async Task<IActionResult> AddCustomer(Customer customer)
        {
            if (ModelState.IsValid)
            {
                // Set PartitionKey and RowKey for the customer
                customer.PartitionKey = "CustomersPartition";
                customer.RowKey = Guid.NewGuid().ToString();

                var json = JsonConvert.SerializeObject(customer);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                // Ensure correct URL format with a trailing slash
                var response = await _httpClient.PostAsync(FunctionBaseUrl + "StoreTableData", content);

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Error adding customer.");
                }
            }
            return View("Create", customer);
        }

        [HttpPost]
        public async Task<IActionResult> DeleteCustomer(string partitionKey, string rowKey)
        {
            // Ensure correct URL format with a trailing slash
            var response = await _httpClient.DeleteAsync($"{FunctionBaseUrl}DeleteCustomer?partitionKey={partitionKey}&rowKey={rowKey}");

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Error deleting customer.");
            }

            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Index()
        {
            // Ensure correct URL format with a trailing slash
            var response = await _httpClient.GetAsync(FunctionBaseUrl + "getallcustomers");

            if (response.IsSuccessStatusCode)
            {
                var jsonResponse = await response.Content.ReadAsStringAsync();
                var customers = JsonConvert.DeserializeObject<List<Customer>>(jsonResponse);
                return View(customers);
            }

            return View(new List<Customer>());
        }
    }
}
