﻿using KikiStore.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;

namespace KikiStore.Controllers
{
    public class FilesController : Controller
    {
        private readonly HttpClient _httpClient;
        private const string FunctionBaseUrl = "https://retailapp-st10279488.azurewebsites.net/";

        public FilesController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IActionResult> Index()
        {
            List<FileModel> files = new List<FileModel>();
            try
            {
                var response = await _httpClient.GetAsync($"{FunctionBaseUrl}ListFiles?directoryName=uploads");

                if (response.IsSuccessStatusCode)
                {
                    var jsonResponse = await response.Content.ReadAsStringAsync();
                    files = JsonConvert.DeserializeObject<List<FileModel>>(jsonResponse);
                }
                else
                {
                    ViewBag.Message = "Failed to load files. Server returned an error.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = $"Failed to load files: {ex.Message}";
            }

            return View(files);
        }

        [HttpPost]
        public async Task<IActionResult> Upload(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                ModelState.AddModelError("file", "Please select a file to upload.");
                return await Index();
            }

            try
            {
                string directoryName = "uploads";
                string fileName = file.FileName;

                using (var stream = new MemoryStream())
                {
                    await file.CopyToAsync(stream);
                    stream.Position = 0;

                    var content = new StreamContent(stream);
                    content.Headers.Add("Content-Type", "application/octet-stream");

                    var uploadUrl = $"{FunctionBaseUrl}UploadFile?directoryName={directoryName}&fileName={fileName}";
                    var response = await _httpClient.PostAsync(uploadUrl, content);

                    if (response.IsSuccessStatusCode)
                    {
                        TempData["Message"] = $"File '{fileName}' uploaded successfully!";
                    }
                    else
                    {
                        TempData["Message"] = $"File upload failed. Server returned an error.";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["Message"] = $"File upload failed: {ex.Message}";
            }

            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> DownloadFile(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                return BadRequest("File name cannot be null or empty.");
            }

            try
            {
                var response = await _httpClient.GetAsync($"{FunctionBaseUrl}DownloadFile?fileName={fileName}");

                if (response.IsSuccessStatusCode)
                {
                    var fileStream = await response.Content.ReadAsStreamAsync();
                    return File(fileStream, "application/octet-stream", fileName);
                }
                else
                {
                    ModelState.AddModelError("", "Error downloading file. Server returned an error.");
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Error downloading file: {ex.Message}");
            }

            return RedirectToAction("Index");
        }
    }
}
