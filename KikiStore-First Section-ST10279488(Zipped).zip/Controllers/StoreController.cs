﻿using KikiStore.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace KikiStore.Controllers
{
    public class StoreController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly string FunctionBaseUrl = "https://retailapp-st10279488.azurewebsites.net/";


        public StoreController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        [HttpGet]
        public IActionResult AddStore()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddStore(Store store, IFormFile file)
        {
            // Check if a file has been uploaded
            if (file != null && file.Length > 0)
            {
                using var stream = file.OpenReadStream();
                var content = new StreamContent(stream);
                var response = await _httpClient.PostAsync(FunctionBaseUrl + "UploadStoreImage", content);

                // Check for a successful image upload
                if (response.IsSuccessStatusCode)
                {
                    store.ImageUrl = await response.Content.ReadAsStringAsync();
                }
                else
                {
                    ModelState.AddModelError("", "Error uploading store image.");
                    return View(store);
                }
            }

            // Check if the model state is valid before saving the store
            if (ModelState.IsValid)
            {
                store.PartitionKey = "StoresPartition";
                store.RowKey = Guid.NewGuid().ToString();

                var json = JsonConvert.SerializeObject(store);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync(FunctionBaseUrl + "AddStore", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }

                ModelState.AddModelError("", "Error adding store.");
            }
            return View(store);
        }

        [HttpPost]
        public async Task<IActionResult> DeleteStore(string partitionKey, string rowKey)
        {
            // Corrected URL for deleting the store
            var response = await _httpClient.DeleteAsync($"{FunctionBaseUrl}DeleteStore?partitionKey={partitionKey}&rowKey={rowKey}");

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            ModelState.AddModelError("", "Error deleting store.");
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Index()
        {
            // Corrected URL for fetching all stores
            var response = await _httpClient.GetAsync(FunctionBaseUrl + "GetAllStores");

            if (response.IsSuccessStatusCode)
            {
                var jsonResponse = await response.Content.ReadAsStringAsync();
                var stores = JsonConvert.DeserializeObject<List<Store>>(jsonResponse);
                return View(stores);
            }

            // Return an empty list in case of an error
            return View(new List<Store>());
        }
    }
}

