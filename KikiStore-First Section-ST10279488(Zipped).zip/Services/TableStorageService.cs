﻿using Azure.Data.Tables;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using KikiStore.Models;

namespace KikiStore.Services
{
    public class TableStorageService
    {
        private readonly HttpClient _httpClient;

        private const string FunctionBaseUrl = "https://retailapp-st10266958.azurewebsites.net";

        public TableStorageService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task AddCustomerAsync(Customer customer)
        {
            var json = JsonConvert.SerializeObject(customer);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync(FunctionBaseUrl + "StoreTableData", content);

            if (!response.IsSuccessStatusCode)
            {
                throw new HttpRequestException("Error adding customer.");
            }
        }

        public async Task DeleteCustomerAsync(string partitionKey, string rowKey)
        {
            var response = await _httpClient.DeleteAsync($"{FunctionBaseUrl}DeleteCustomer?partitionKey={partitionKey}&rowKey={rowKey}");
            if (!response.IsSuccessStatusCode)
            {
                throw new HttpRequestException("Error deleting customer.");
            }
        }

        public async Task<List<Customer>> GetAllCustomersAsync()
        {
            var response = await _httpClient.GetAsync(FunctionBaseUrl + "GetAllCustomers");
            if (response.IsSuccessStatusCode)
            {
                var jsonResponse = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<List<Customer>>(jsonResponse);
            }

            return new List<Customer>();
        }
    }
}
