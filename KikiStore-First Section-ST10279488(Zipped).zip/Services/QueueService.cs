﻿using Azure.Storage.Queues;
using System.Threading.Tasks;

namespace KikiStore.Services
{
    public class QueueService
    {
        private readonly QueueClient _queueClient;

        public QueueService(string connectionString, string queueName)
        {
            _queueClient = new QueueClient(connectionString, queueName);
            EnsureQueueExistsAsync().GetAwaiter().GetResult();
        }

        private async Task EnsureQueueExistsAsync()
        {
            await _queueClient.CreateIfNotExistsAsync();
        }

        // Sends a message to the queue
        public async Task SendMessageAsync(string message)
        {
            await _queueClient.SendMessageAsync(message);
        }

        // Receive a message from the queue
        public async Task<string?> ReceiveMessageAsync()
        {
            var message = await _queueClient.ReceiveMessageAsync();
            if (message != null && message.Value != null)
            {
                await _queueClient.DeleteMessageAsync(message.Value.MessageId, message.Value.PopReceipt);
                return message.Value.MessageText;
            }
            return null;
        }
    }
}
