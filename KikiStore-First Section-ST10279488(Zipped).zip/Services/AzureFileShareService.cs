﻿using Azure.Storage.Files.Shares;
using System.IO;
using System.Threading.Tasks;

namespace KikiStore.Services
{
    public class AzureFileShareService
    {
        private readonly ShareClient _shareClient;

        public AzureFileShareService(string connectionString)
        {
            _shareClient = new ShareClient(connectionString, "myfileshare");
        }

        public async Task<string> UploadFileAsync(Stream fileStream, string fileName)
        {
            // Ensure the file share exists
            await _shareClient.CreateIfNotExistsAsync();

            ShareDirectoryClient rootDir = _shareClient.GetRootDirectoryClient();
            ShareFileClient fileClient = rootDir.GetFileClient(fileName);

            await fileClient.CreateAsync(fileStream.Length);
            await fileClient.UploadAsync(fileStream);

            return $"File {fileName} uploaded successfully.";
        }

        public async Task<Stream> DownloadFileAsync(string fileName)
        {
            // Get the root directory of the file share
            ShareDirectoryClient rootDir = _shareClient.GetRootDirectoryClient();
            ShareFileClient fileClient = rootDir.GetFileClient(fileName);

            if (await fileClient.ExistsAsync())
            {
                // Download the file and return the stream
                var downloadResponse = await fileClient.DownloadAsync();
                return downloadResponse.Value.Content;
            }

            return null; // Return null if the file doesn't exist
        }
    }
}
